import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class Model {
  constructor(
    public id: number,
    public amount: string,
    public currencyType: string,
    public fromAcc?: string,
    public toAcc?: string,
    public bicId?: string,
  ) {  }

}
}
