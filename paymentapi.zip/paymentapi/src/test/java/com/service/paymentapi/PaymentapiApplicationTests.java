package com.service.paymentapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
